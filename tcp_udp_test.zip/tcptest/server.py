
import threading
import time
import socket
def job(num):
    while 1:
        recevent = connect_socket.recv(1024)
        print(str(recevent,encoding='gbk'))
        if str(recevent,encoding='gbk') == 'quit': break

hostname = '127.0.0.1' #設定主機名
port = 6665  #設定埠號 要確保這個埠號沒有被使用，可以在cmd裡面檢視
addr = (hostname,port)
srv = socket.socket() #建立一個socket
srv.bind(addr)
srv.listen(5)
print("waitting connect")
i = 0
threads = []
while True:
    connect_socket,client_addr = srv.accept()
    print(client_addr)
    threads.append(threading.Thread(target = job, args = (i,)))
    threads[i].start()
    i = i + 1
    
connect_socket.close()
