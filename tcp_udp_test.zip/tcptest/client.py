
import socket
hostname = '127.0.0.1'
port = 6665
addr = (hostname,port)
clientsock = socket.socket() ## 建立一個socket
clientsock.connect(addr) # 建立連線

while 1:
    say = input("輸入你想傳送的訊息：")
    clientsock.send(bytes(say,encoding='gbk')) #傳送訊息
    #recvdata = clientsock.recv(1024)  #接收訊息 recvdata 是bytes形式的
    #print(str(recvdata,encoding='gbk')) # 我們看不懂bytes，所以轉化為 str
    if say == 'quit': break
clientsock.close()
