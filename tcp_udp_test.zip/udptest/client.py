#UDPclient.py
import socket


def UdpClient():
        Host = '127.0.0.1'
        Port = 5000
        s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

        #input使用者自定義訊息
        str1 = input('Input some messages: ')

        #sendto(string,(IP,PORT))    string是要傳送的資訊,IP是目標(server)的IP,PORT目標埠,上面我定義的是5000
        s.sendto(str1.encode(),(Host,Port))   #str1.encode()編碼後傳送,接收端需要decode
        s.close()
        return str1

while True:
        str1 = UdpClient()
        if str1 =='quit':
                break
